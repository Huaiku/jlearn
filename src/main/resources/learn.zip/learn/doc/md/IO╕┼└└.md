# IO概览



<table  border=1>
	<tr>
        <th rowspan=2></th>
		<th colspan=2>Byte Based</th>
		<th colspan=2>Charater Based</th>
	</tr>
    <tr>
        <td><strong>Input</strong></td>
        <td><strong>Output</strong></td>
        <td><strong>Input</strong></td>
        <td><strong>Output</strong></td>
    </tr>
    <tr>
    	<td>Basic</td>
        <td>InputStream</td>
        <td>OutputStream</td>
        <td>ReaderInputStream</td>
        <td>WriteOutputStream</td>
    </tr>
    <tr>
    	<td>Arrrays</td>
        <td>ByteArrayInputStream</td>
        <td>ByteArrayOutputStream</td>
        <td>CharArrayReader</td>
        <td>CharArrayWriter</td>
    </tr>
    <tr>
    	<td>Files</td>
        <td>FileInputStream
            RandomAccessFile</td>
        <td>FileOutputStream
            RandomAccessFile</td>
        <td>FileReader</td>
        <td>FileWriter</td>
    </tr>
    <tr>
    	<td>Pipes</td>
        <td>PipedInputStream</td>
        <td>PipedOutputStream</td>
        <td>PipedReader</td>
        <td>PipedWriter</td>
    </tr>
    <tr>
    	<td>Buffering</td>
        <td>BufferedInputStream</td>
        <td>BufferedOutputStream</td>
        <td>BufferedReader</td>
        <td>BufferedWriter</td>
    </tr>
     <tr>
    	<td>Filtering</td>
        <td>FilterInputStream</td>
        <td>FilterOutputStream</td>
        <td>FilterReader</td>
        <td>FilterWriter</td>
    </tr>
     <tr>
    	<td>Parsing</td>
        <td>PushbakInputStream
            StreamTokenizer</td>
        <td></td>
        <td>PushbakReader
            LineNumberReader</td>
        <td></td>
    </tr>
     <tr>
    	<td>Strings</td>
        <td></td>
        <td></td>
        <td>StringReader</td>
        <td>StringWriter</td>
    </tr>
     <tr>
    	<td>Data</td>
        <td>DataInputStream</td>
        <td>DataOutputStream</td>
        <td></td>
        <td></td>
    </tr>
     <tr>
    	<td>Data-Formatted</td>
        <td></td>
        <td>PrintStream</td>
        <td></td>
        <td>PrintWriter</td>
    </tr>
     <tr>
    	<td>Objects</td>
        <td>ObjectInputStream</td>
        <td>ObjectOutputStream</td>
        <td></td>
        <td></td>
    </tr>
      <tr>
    	<td>Utilities</td>
        <td>SequenceInputStream</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>


## JAVA NIO

> ### 通道和缓冲区的概念
>
> - Channels and Buffers 通道和缓冲区
>
>   > 标准IO是基于字节流和字符流的操作，而NIO是基于通道和缓冲区的操作，数据总是有通道=>缓冲区或者缓冲区=> 通道
>
> - Non-blocking IO 非阻塞式IO
>
>   > NIO是非阻塞式IO，当线程从通道=>缓冲区 或者缓冲区=> 通道进行数据读写时，线程依然可以干其他事情，不必阻塞等待
>
> - Selector 选择器
>
>   > NIO引入选择器，选择器可以用于监听多个通道事件如打开链接，数据到达等，因此单个线程可以监听多个数据通道
>
> #### 通道和缓冲区的相关实现
>
> - 通道的部分实现
>
>   > 通道的实现是根据我们操作的数据对象类型划分其中部分重要实现如下，其主要都是围绕UDP，TCP，网络IO，以及IO。
>   >
>   > - FileChannel
>   > - DatagramChannel
>   > - SocketChannel
>   > - ServerSocketChannel
>
> - 缓冲区的部分实现
>
>   > 数据缓冲区主要是围绕操作的数据类型来实现相应的对象。例如
>   >
>   > - ByteBuffer
>   > - CharBuffer
>   > - DoubleBuffer
>   > - FloatBuffer
>   > - IntBuffer
>   > - LongBuffer
>   > - ShortBuffer
>   > - MappedByteBuffer 内存映射文件
>



