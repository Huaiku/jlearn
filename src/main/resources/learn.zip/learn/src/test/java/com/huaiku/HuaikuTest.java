package com.huaiku;

/**
 * Unit test for simple App.
 */
public class HuaikuTest {
	public static void main(String args[]) {
		StringBuilder sqlBuilder = new StringBuilder(
				"SELECT CZ.ID,CZ.LESSEECONTRACTCODE,CZ.CONTRACTID,CZ.CONTRACTENDDATE,");
		sqlBuilder.append(
				" CZ.CONTRACTSTARTDATE,CASE WHEN CZ.PRE_TERMINATION_STATE = '1' AND CZ.contractState<>'1000200010005' THEN CZ.contractenddate ELSE CZ.real_end_date END AS REAL_END_DATE,CZJY.TERMINATIONDATE,CZ.CHECKTIME,CZ.INCOMEDATE,CZ.ROOMID,")
				.append(" CZJY.TERMINATIONCODE,CZJY.TERMINATIONTYPE,CZJY.CHECKTIME AS JY_CHECKTIME,NVL(CYC.CYCLEINFO,'\"cycleInfo\":[]') AS CYCLEINFO")
				.append(" FROM WK_CF_CONTRACT CZ").append(" LEFT JOIN WK_CF_JY_TERMINATION CZJY")
				.append(" ON CZJY.CONTRACTID = CZ.ID AND CZJY.ISDEL = ? AND CZJY.CHECKSTATE = ?")
				.append(" LEFT JOIN (SELECT CONTRACTID,'{\"cycleInfo\":[' ||")
				.append(" LISTAGG('{\"period\":' || NVL(PERIOD,1) || ',\"cycleStart\":\"' ||TO_CHAR(RENTFREESTARTTIME, 'yyyy-MM-dd') ||")
				.append(" '\",\"cycleEnd\":\"' ||TO_CHAR(RENTFREEENDTIME, 'yyyy-MM-dd') ||'\",\"cycleRentPrice\":' || MONTHPRICE  || '}',")
				.append(" ',') WITHIN GROUP(ORDER BY PERIOD) || ']}' CYCLEINFO FROM WK_CF_CYCLE WHERE ISDEL = 1")
				.append(" GROUP BY CONTRACTID) CYC ON CYC.CONTRACTID = CZ.ID")
				.append(" WHERE CZ.ISDEL = ? AND CZ.CHECKSTATE = ?").append(" AND CZ.CONTRACTID NOT IN ")
				.append(" (SELECT SF.ID FROM WK_SF_CONTRACT SF WHERE PRODUCT_TYPE = ? AND ISDEL = ?)");
		
		System.out.println(sqlBuilder.toString());
	}
}
