package com.huaiku.pojo;

import java.io.Serializable;

/**
 * 
 * @description user's informations
 * @author junit
 * @date Nov 6, 2018-10:03:37 AM
 */
public class User implements Serializable{
	
	//FIXME Know the usage of serialVersionID .
	private static final long serialVersionUID = -5824156918534145843L;
	
	private String name;
	private int age;
	private String gender;

	public String getName() {
		return name;
	}

	public User setName(String name) {
		this.name = name;
		return this;
	}

	public int getAge() {
		return age;
	}

	public User setAge(int age) {
		this.age = age;
		return this;
	}

	public String getGender() {
		return gender;
	}

	public User setGender(String gender) {
		this.gender = gender;
		return this;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", age=" + age + ", gender=" + gender + "]";
	}
}
