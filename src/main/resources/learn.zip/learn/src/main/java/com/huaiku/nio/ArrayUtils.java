package com.huaiku.nio;

/**
 * 
 * @description array utils
 * @author kuaiku
 * @date Nov 7, 2018-3:22:02 PM
 */
public class ArrayUtils {
	/**
	 * link two byte array
	 * 
	 * @param source
	 * @param target
	 * @return
	 */
	public static byte[] concatarray(byte[] s1, byte[] s2) {
		byte[] newCopy = new byte[s1.length + s2.length];
		System.arraycopy(s1, 0, newCopy, 0, s1.length);
		System.arraycopy(s2, 0, newCopy, s1.length, s2.length);
		return newCopy;
	}
}
