package com.huaiku.utils;

import java.util.function.Predicate;

/**
 * 
 * @description condition check
 * @author junit
 * @date Nov 7, 2018-11:44:49 AM
 */
public class Conditions {
}
