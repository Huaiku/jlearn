package com.huaiku;

import com.huaiku.nio.ArrayUtils;

/**
 * 
 * @description
 * @author junit
 * @date Nov 6, 2018-9:58:11 AM
 */
public class Huaiku {
	public static void main(String[] args) {
		byte[] a = new byte[] {1,2,3,4};
		byte[] b = new byte[] {4,5,6};
		byte[] c =ArrayUtils.concatarray(a, b);
		System.out.println(c.length);
		
		for(byte bt:c) {
			System.out.print(String.format("%d,", bt));
		}
		
		byte[] finalDataArray = new byte[] {};
		
		System.out.println(String.format("Size=> %d",finalDataArray.length));
	}
}
