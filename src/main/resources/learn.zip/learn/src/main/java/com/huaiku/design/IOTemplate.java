package com.huaiku.design;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.function.Function;

/**
 * 
 * @description IO operate template
 * @author junit
 * @date Nov 6, 2018-10:12:10 AM
 */
public class IOTemplate {

	/**
	 * A template method for InputStream
	 * 
	 * @param e
	 * @param function
	 * @return
	 */
	public static <T> T applyObjectInput(String e, Function<InputStream, T> function) {

		T t = null;
		InputStream input = null;
		ObjectInputStream objectInput = null;

		try {

			input = new FileInputStream(e);
			objectInput = new ObjectInputStream(input);
			t = function.apply(objectInput);

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {

			if (input != null) {
				try {
					input.close();
				} catch (Exception exx) {
					System.out.println(exx.getMessage());
				}
			}

			if (objectInput != null) {
				try {
					objectInput.close();
				} catch (Exception exx) {
					System.out.println(exx.getMessage());
				}

			}
		}

		return t;
	}

	/**
	 * A template method for InputStream
	 * 
	 * @param e
	 * @param function
	 * @return
	 */
	public static <T> T applyObjectOutput(String e, Function<OutputStream, T> function) {

		T t = null;
		OutputStream output = null;
		ObjectOutputStream objectOutput = null;

		try {

			output = new FileOutputStream(e);
			objectOutput = new ObjectOutputStream(output);
			t = function.apply(objectOutput);

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {

			if (output != null) {
				try {
					output.close();
				} catch (Exception exx) {
					System.out.println(exx.getMessage());
				}
			}

			if (objectOutput != null) {
				try {
					objectOutput.close();
				} catch (Exception exx) {
					System.out.println(exx.getMessage());
				}

			}
		}

		return t;
	}
}
