package com.huaiku.io;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.huaiku.design.IOTemplate;
import com.huaiku.pojo.User;

/**
 * 
 * @description the io operations of objects,serialization
 * @author junit
 * @date Nov 6, 2018-10:01:50 AM
 */
public class ObjectsIO {
	public static void main(String args[]) {

		User user = new User();
		user.setName("Huaiku.").setAge(18).setGender("男");
		
		// write object to file
		IOTemplate.applyObjectOutput("objedctFile", (ioStream) -> {
			ObjectOutputStream out = (ObjectOutputStream) ioStream;
			try {
				out.writeObject(user);
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
			
			System.out.println("write object done ...");
			return "objedctFile";
		});
		
		// read object from file
		String finalResult = IOTemplate.applyObjectInput("objedctFile",(ioStream)->{
			
			ObjectInputStream in = (ObjectInputStream)ioStream;
			User u = null;
			try {
				u = (User) in.readObject();
			} catch (ClassNotFoundException | IOException e) {
				System.out.println(e.getMessage());
			}
			System.out.println("read object done ...");
			return u.toString();
		});
		
		System.out.println(String.format("Object's info %s", finalResult));
	}
}
