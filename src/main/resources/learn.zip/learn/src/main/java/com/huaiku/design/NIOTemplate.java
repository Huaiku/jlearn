package com.huaiku.design;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.FileChannel;
import java.util.Objects;
import java.util.function.BiFunction;

/**
 * 
 * @description the template of nio operational
 * @author junit
 * @date Nov 7, 2018-11:27:59 AM
 */
public class NIOTemplate {
	/**
	 * @param path path to build a channel
	 * @param bi   nio operate
	 * @return
	 */
	public static <T> T apply(String filePath, BiFunction<FileChannel, ByteBuffer, T> bi) {
		FileChannel channel = null;
		ByteBuffer buf = null;
		T t = null;
		RandomAccessFile rafile = null;
		try {
			rafile = new RandomAccessFile(filePath, "rw");
			channel = rafile.getChannel();
			// initial size 1MB
			buf = ByteBuffer.allocate(10240);
			t = bi.apply(channel, buf);

		} catch (Exception e) {

			System.out.println(String.format("ErrorType => %s,ErrorMessage => %s", e.getClass(), e.getMessage()));
		} finally {

			if (Objects.nonNull(channel) && channel.isOpen()) {
				try {
					channel.close();
				} catch (IOException e) {
					System.out.println(String.format("Close Channel Error => %s", e.getMessage()));
				}
			}

			if (Objects.nonNull(rafile)) {
				try {
					rafile.close();
				} catch (IOException e) {
					System.out.println(String.format("Close Channel Error => %s", e.getMessage()));
				}
			}
		}
		return t;
	}

	/**
	 * @param path path to build a channel
	 * @param bi   nio operate
	 * @return
	 */
	public static <T> T apply(BiFunction<Channel, Buffer, T> bi) {
		Channel channel = null;
		Buffer buf = null;
		T t = null;
		try {
			t = bi.apply(channel, buf);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (Objects.nonNull(channel) && channel.isOpen()) {
				try {
					channel.close();
				} catch (IOException e) {
					System.out.println(String.format("Close Channel Error => %s", e.getMessage()));
				}
			}
		}
		return t;
	}
}
