package com.huaiku.nio;

import java.io.IOException;
import java.util.Objects;
import com.huaiku.design.NIOTemplate;

/**
 * 
 * @description the usage of FileChannel
 * @author junit
 * @date Nov 7, 2018-11:11:04 AM
 */
public class FileChannelExample {

	public static void main(String args[]) throws IOException {

		String path = "/Users/junit/Documents/workspace-spring-tool-suite/learn/src/main/resources/hello.txt";

		String text = NIOTemplate.apply(path, (channel, buffer) -> {
			byte[] finalDataArray = new byte[] {};
			try {
				int readSize = channel.read(buffer);
				while (readSize != -1) {
					// transfer write mode to read mode,and read data from buffer
					buffer.flip();
					int remaining = 0;
					int defaultCacheSize = 1024;
					byte[] arr = null;
					while (buffer.hasRemaining()) {

						remaining = buffer.remaining();
						if (remaining >= defaultCacheSize) {
							if (Objects.isNull(arr)) {
								arr = new byte[defaultCacheSize];
							}
						} else {
							arr = new byte[remaining];
						}

						// 从缓冲区读数据到数组
						buffer.get(arr);
						finalDataArray = ArrayUtils.concatarray(finalDataArray, arr);
					}

					buffer.clear();
					// rewrite data from channel to buffer
					readSize = channel.read(buffer);
				}
			} catch (IOException e) {
				System.out.println(String.format("Error => %s", e.getMessage()));
			}
			
			// 字符数组封装
			return new String(finalDataArray);
		});

		System.out.println(text);
	}
}
