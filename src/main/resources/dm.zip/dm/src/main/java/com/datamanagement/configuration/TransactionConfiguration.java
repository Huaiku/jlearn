package com.datamanagement.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * 
 * @description transaction manager register and configuration
 * @author huaiku
 * @date Nov 13, 2018-10:49:05 AM
 * 
 */
@Configuration
@EnableTransactionManagement
public class TransactionConfiguration {
	
	/**
	 * register transaction manager
	 * @return transaction manager
	 */
	@Bean
	public PlatformTransactionManager transactionManager() {
		JpaTransactionManager txManager = new JpaTransactionManager();
		return txManager;
	}
}
