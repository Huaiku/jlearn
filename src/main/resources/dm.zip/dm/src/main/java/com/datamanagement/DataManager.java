package com.datamanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * @description 程序入口
 * @author huaiku
 * @date Nov 9, 2018-5:25:18 PM
 */
@SpringBootApplication
public class DataManager {
	
	public static void main(String args[]) {
		SpringApplication.run(DataManager.class, args);
	}

}