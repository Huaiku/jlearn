package com.datamanagement.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * 
 * @description 程序启动后紧接着需要执行的操作
 * @author huaiku
 * @date Nov 9, 2018-8:00:08 PM
 */
@Configuration
public class OnApplicationReady {
	
	private static final Logger logger = LoggerFactory.getLogger(OnApplicationReady.class);
	
	@Bean
	public CommandLineRunner init(ApplicationContext context) {
		return (args)->{
			logger.info("application started!");
		};
	}
}
