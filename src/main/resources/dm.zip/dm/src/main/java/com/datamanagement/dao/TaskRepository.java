package com.datamanagement.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import com.datamanagement.entities.Task;

/**
 * 
 * @description schedule task CRUD operate
 * @author Huaiku
 * @date Nov 12, 2018-11:13:18 PM
 * @version v1.0
 */
public interface TaskRepository extends CrudRepository<Task, Long> {
	
	/**
	 * 
	 * @description query task by task name
	 * @author huaiku
	 * @param taskName
	 * @return an optional task object
	 */
	Optional<Task> findByTaskName(String taskName);
}
