package com.datamanagement.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "table")
public class Task implements Serializable {

	private static final long serialVersionUID = -3404716977193348021L;

	// 主键
    @Id
    @GeneratedValue
    private long id;

    // 任务名
    @Column(nullable = false, columnDefinition = "task_name",unique = true)
    private String taskName;

    // 任务组
    @Column(nullable = false,columnDefinition = "task_group")
    private String taskGroup;

    // 开始时间
    @Column(columnDefinition = "start_time")
    private LocalDateTime startTime;

    // 结束时间
    @Column(columnDefinition = "end_time")
    private LocalDateTime endTime;

    // CRON表达式
    @Column(columnDefinition = "cron_expression")
    private String cronExpression;
    
    // 任务状态
    @Column
    private int status;
    
    // 任务描述
    @Column
    private String desc;

    // 创建者
    @Column
    private String creator;

    // 创建时间
    @Column(columnDefinition = "create_time")
    private LocalDateTime createTime;

     // 修改人
    @Column
    private String modifier;

    // 修改时间
    @Column(columnDefinition = "modified_time")
    private LocalDateTime modifiedTime;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskGroup() {
        return taskGroup;
    }

    public void setTaskGroup(String taskGroup) {
        this.taskGroup = taskGroup;
    }

    public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public LocalDateTime getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(LocalDateTime modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

}
