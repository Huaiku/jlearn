package com.datamanagement;

public class NT {
	public static void main(String args[]) {
		String name = "WE115_反馈_20181112075837.xlsx";
		int offset = name.lastIndexOf("_") + 1;
		String dateStr = name.substring(offset, offset + 14);
		int hour = Integer.parseInt(dateStr.substring(8, 10));

		System.out.println(dateStr.substring(8, 10));
		System.out.println(hour);
	}
}
